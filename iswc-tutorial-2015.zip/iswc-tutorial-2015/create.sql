CREATE TABLE "tbl_patient" (
patientid INT NOT NULL PRIMARY KEY,
name VARCHAR(40),
type BOOLEAN,
stage TINYINT
)